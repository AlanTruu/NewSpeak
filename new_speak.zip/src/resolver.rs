use std::collections::HashMap;
use crate::statement::Stmt;
use crate::grammar::Expr;
use crate::lex::Token;

struct Resolver {
    scopes : Vec<HashMap<String, bool>>
}

impl Resolver {
    pub fn read(&mut self, stmts : &[Stmt]) {
        for statements in stmts {
            self.resolve_statement(statements);
        }
    }

    fn resolve_statement(&mut self, stmt : &Stmt) {
        match stmt {
            Stmt::Block(block) => {
                self.begin_scope();
                self.read(block);
                self.end_scope();
            },
            Stmt::Var { name, initializer } => {
                if let Some(initializer) = initializer {
                    self.resolve_expr(initializer);
                }
            }
            _ => ()
        }
    }

    fn resolve_expr(&mut self, expr : &Expr) {

    }

    fn begin_scope(&mut self) {
        self.scopes.push(HashMap::new());
    }

    fn end_scope(&mut self) {
        self.scopes.pop();
    }

    pub fn declare(&mut self, name : &Token) {
        if self.scopes.is_empty() {return}

        let scope = self.scopes.last_mut().unwrap();

        scope.insert(name.lexeme.clone(), false);
    }

    pub fn define(&mut self, name : &Token) {
        if self.scopes.is_empty() {return}

        self.scopes.last_mut().unwrap().insert(name.lexeme.clone(), true);
    }
}
